/*
Kayvaun Khoshkhou
CSC340.04 Duc Ta
Assignment 3 Part C
Tic Tac Toe in C++
Due 10/13/2020 11:59 PM
*/

#include <iostream>
#include <vector>
#include <fstream>
#include <string>
using namespace std;

void loadData(vector<string> Data) {
    string str;

    ifstream in("Data.CS.SFSU.txt");

    while (getline(in, str)) {
        if (str.size() > 0)
            Data.push_back(str);
    }

    in.close();
}


// prints data from .txt file
void printData() {
    // make vector to store file contents in.        
    vector<string> Data;
    // variables to manipulate .txt file with.
    string str;
    fstream inFile;
    // the next 3 lines open the file, get the contents, and put it into the Data vector.
    inFile.open("Data.CS.SFSU.txt", ios::in);
    while (getline(inFile, str)) {
        cout << str << endl;
    }
    // this for-loop prints out the contents of the vector. 
    for (int i = 0; i < Data.size(); i++) {
        cout << Data[i] << endl;
    }
    // Closing the file
    inFile.close();
}

// Method to parse the contents by '|' but not complete
// Also return method to put back in main
string parseData(vector<string> updateData) {

    string varName = "Completewhenpossible";

    //vector<string> updateData();
    return varName;
}

// this generic error method is used for when user input is incorrect
void errorMessage(){
    cout << "|" << endl;
    cout << " PARAMETER HOW-TO, please enter" << endl;
    cout << " 1. A search key -then 2. An optional part of speech -then" << endl;
    cout << " 3. An optional 'distinct' -then 4. An optional 'reverse'" << endl;
    cout << "|" << endl;
}


int main()
{
    // Instantiating these variables as global to keep track
    // of searches + do-while loops
    int whileLoop = 0;
    string userInput;
    int currentSearch = 1;
    int big = 0;

    // Generic opening + Keywords/Definitions in vector
    cout << "==== Dictionary 340 C++ ====" << endl;
    cout << "------ Keywords: " << endl;
    cout << "------ Definitions: " << endl;

    do {
        do {
            cout << "Search [" << currentSearch << "]: ";
            cin >> userInput;
            cout << "|" << endl;

        } while (whileLoop == 0);

    } while (big == 0);

    return 0;
}