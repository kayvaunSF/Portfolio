package csc340assignment2;

import java.util.*;
import java.util.Collection;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

public class CSC340Assignment2 {
    
    public enum enumKeywords{
        // Adding Keywords into an Enum
        
        // Arrow keyword with 3 String paramters
        Arrow("Arrow", "Noun", "Here is one arrow: <IMG> -=>> </IMG>"),
        
        // Four Book Keywords with 3 String parameters
        Book1("Book", "Noun", "A set of pages."),
        Book2("Book", "Noun", "A written work published in printed or electronic form."),
        Book3("Book", "Verb", "To arrange for someone to have a seat on a plane."),
        Book4("Book", "Verb", "To arrange something on a particular date."),
        
        // Eight Distinct Keywords with 3 String parameters
        Distinct1("Distinct", "Adjective", "Familiar. Worked in Java."),
        Distinct2("Distinct", "Adjective", "Unique. No duplicates. Clearly different or of a different kind."),
        Distinct3("Distinct", "Adverb", "Uniquely. Written 'distinctly'."),
        Distinct4("Distinct", "Noun", "A keyword in this assignment."),
        Distinct5("Distinct", "Noun", "A keyword in this assignment."),
        Distinct6("Distinct", "Noun", "A keyword in this assignment."),
        Distinct7("Distinct", "Noun", "An advanced search option."),
        Distinct8("Distinct", "Noun", "Distinct is a parameter in this assignment."),
        
        // Eleven Placeholder Keywords with 3 String parameters
        Placeholder1("Placeholder", "Adjective", "To be updated..."),
        Placeholder2("Placeholder", "Adjective", "To be updated..."),
        Placeholder3("Placeholder", "Adverb", "To be updated..."),
        Placeholder4("Placeholder", "Conjunction", "To be updated..."),
        Placeholder5("Placeholder", "Interjection", "To be updated..."),
        Placeholder6("Placeholder", "Noun", "To be updated..."),
        Placeholder7("Placeholder", "Noun", "To be updated..."),
        Placeholder8("Placeholder", "Noun", "To be updated..."),
        Placeholder9("Placeholder", "Preposition", "To be updated..."),
        Placeholder10("Placeholder", "Pronoun", "To be updated..."),
        Placeholder11("Placeholder", "Verb", "To be updated..."),
        
        // Fifteen Reverse Keywords with 3 String parameters
        Reverse1("Reverse", "Adjective", "On back side."),
        Reverse2("Reverse", "Adjective", "Opposite to usual or previous arrangement."),
        Reverse3("Reverse", "Noun", "A dictionary program's parameter."),
        Reverse4("Reverse", "Noun", "Change to opposite direction."),
        Reverse5("Reverse", "Noun", "The opposite."),
        Reverse6("Reverse", "Noun", "To be updated..."),
        Reverse7("Reverse", "Noun", "To be updated..."),
        Reverse8("Reverse", "Noun", "To be updated..."),
        Reverse9("Reverse", "Noun", "To be updated..."),
        Reverse10("Reverse", "Verb", "Change something to opposite."),
        Reverse11("Reverse", "Verb", "Go back."),
        Reverse12("Reverse", "Verb", "Revoke ruling."),
        Reverse13("Reverse", "Verb", "To be updated..."),
        Reverse14("Reverse", "Verb", "To be updated..."),
        Reverse15("Reverse", "Verb", "Turn something inside out.");

        
        // Constructors for Enum
        private String eKey;
        private String ePOSpeech;
        private String eDefinition;
        
        //Enum Method Setters
        private enumKeywords(String eKey, String ePOSpeech, String eDefinition){
        this.eKey = eKey;
        this.ePOSpeech = ePOSpeech;
        this.eDefinition = eDefinition;
        }
        
        // Enum Getters for the next 3 methods
        public String geteKey() {
            return eKey;    
        }
        
        public String getePOSpeech(){
            return ePOSpeech;
        }
        
        public String geteDefinition(){
            return eDefinition;
        }
        
        // ToString method for output
        @Override
        public String toString() {
            return this.eKey + ", [" + this.ePOSpeech + "] , " + this.eDefinition;
        }
               
               
    }
    
    public static void main(String[] args) {
        
        // to make an array to take values from the enum
        enumKeywords[] wordArray = enumKeywords.values();
        
        // System.out.println(wordArray); Testing to see output, not important
        
        // to make an ArrayList with the enum in mind 
        ArrayList<enumKeywords> wordArrayList = new ArrayList<enumKeywords>();
        
        // for variable "keys" in enumKeywords, fill with content from wordArray
        for(enumKeywords keys : wordArray){
            wordArrayList.add(keys);
        }
        System.out.println(wordArrayList);
        
        // Checking clear method to see if it works, erases all content inside ArrayList
        wordArrayList.clear();
        
        // Scanner Object to test user input
        Scanner s = new Scanner(System.in);
        String userinput = s.next();
        
        // For Loop to add content in array into ArrayList + comparing data at lower case
        for (enumKeywords keys : wordArray){
            if(keys.geteKey().toLowerCase().equals(userinput.toLowerCase())){
                wordArrayList.add(keys);
            }
        }
        
        // Testing reverse method
        System.out.println(wordArrayList);
        wordArrayList = CSC340Assignment2.reverse(wordArrayList);
        System.out.println(wordArrayList);
//        System.out.println(wordArrayList);
                        
    }
    
    
    // Making Distinct Method to get unique definition output
    public static ArrayList<enumKeywords> distinct(ArrayList<enumKeywords> array){
        // Creating new ArrayList
        ArrayList<enumKeywords> checkDistinct = array;
        String aSpeech;
        String aDef;
        String bSpeech;
        String bDef;
        // test variable
        ArrayList<Integer> flag = new ArrayList<Integer>();
        
        // For loop to go through enum and get the second and third String
        for(int i = 0; i < checkDistinct.size() - 1; i++) {
            aSpeech = checkDistinct.get(i).getePOSpeech();
            aDef = checkDistinct.get(i).geteDefinition();
              // Same for loop          
            for (int h = 1; i < checkDistinct.size(); h++) {
                bSpeech = checkDistinct.get(h).getePOSpeech();
                bDef = checkDistinct.get(h).geteDefinition();
                // If statement to compare
                if(aSpeech.equals(bSpeech) && aDef.equals(bDef)){
                    flag.add(i);
                    break;
                }
         }
        }
        // For loop to remove similar objects to get unique value
        int counter;
        for(int c = flag.size() - 1; c >= 0; c--){
            counter = flag.get(c);
            checkDistinct.remove(counter);
        }
        return checkDistinct;
    }
    
    // Reverse method, returns the called keywords backwards. Iterated backwards**
    public static ArrayList<enumKeywords> reverse(ArrayList<enumKeywords> array){
        // make new ArrayList using enum
        ArrayList <enumKeywords> toReverse = new ArrayList<enumKeywords>();
        // transverse the arrayList and iterate it backwards
        for(int i = array.size() - 1; i >= 0; i--) {
            toReverse.add(array.get(i));
        }
        // easy return
        return toReverse;
    }
    
}

