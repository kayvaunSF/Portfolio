
package assignment4parta;

/**
 *
 * @author Kayvaun
 */

class Sorting {
    public static void printArray(int[] arr) {
        for(int i = 0; i < arr.length; i++)
            System.out.print(arr[i] + " ");
            System.out.println();
    }
    public static void selectionSort(int[] arr) {
        int i, n, bottomIndex, temp;
        for (i = 0; i < (arr.length - 1); i++) {
            bottomIndex = i;
            for (n = i + 1; n < arr.length; n++) {
                if (arr[n] < arr[bottomIndex]) {
                    bottomIndex = n;
                }
            }
            temp = arr[i];
            arr[i] = arr[bottomIndex];
            arr[bottomIndex] = temp;
            printArray(arr);
        }
    }
    public static void bubbleSort(int[] arr) {
        int i, n, temp;
        for(i = 0; i < arr.length; i++) {
            for(n = 0; n < arr.length - i - 1; n++) {
                if(arr[n] > arr[n + 1]) {
                    temp = arr[n];
                    arr[n] = arr[n + 1];
                    arr[n + 1] = temp;
                }
            }
            printArray(arr);
        }
    }
    public static void shellSort(int[] arr) {
        int i, n, z, temp;
        for (z = arr.length/2; z > 0; z = z/2) {
            for (i = z; i < arr.length; i++) {
                temp = arr[i];
                for (n = i; n >= z && temp < arr[n - z]; n = n - z) {
                    arr[n] = arr[n - z];
                }
                arr[n] = temp;
                printArray(arr);
            }
        }
    }
    public static void main(String[] args) {
        int selSort[] = {9, 4, 9, 8, 3, 5, 6, 2, 9, 7, 5, 1};
        System.out.print("Original Array : ");
        printArray(selSort);
        System.out.println("Selection sort : ");
        selectionSort(selSort);

        int insSort[] = {9, 4, 9, 8, 3, 5, 6, 2, 9, 7, 5, 1};
        System.out.print("Original Array : ");
        printArray(insSort);
        System.out.println("Bubble sort : ");
        bubbleSort(insSort);

        int shellSort[] = {9, 4, 9, 8, 3, 5, 6, 2, 9, 7, 5, 1};
        System.out.print("Original Array : ");
        printArray(shellSort);
        System.out.println("Shell sort : ");
        shellSort(shellSort);
    }
}    
    

